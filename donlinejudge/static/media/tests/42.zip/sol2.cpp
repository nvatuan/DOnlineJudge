#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int prime(int i) {
    if (i < 2) return 0;
    if (i==2) return 1;
    for (int d=2; 1LL*d*d<=i; d++)
        if (i%d==0) return 0;
    return 1;
}

string s;
int check(int x) {
    int p=(int)s.length()-1;
    while (x) {
        if (s[p]=='?'||((s[p]-'0')==(x%10))) {
            p--;
            x/=10;
        } else return 0;
    }
    return 1;
}

int main() {
    cin >> s;
    
    int st=1;
    for (int i=1; i<s.length(); i++) st *= 10;

    int ans=0;
    for (int i=st; i<st*10; i++) {
        if (check(i)) {
            ans += prime(i);
        }
    }
    cout << ans;
}

