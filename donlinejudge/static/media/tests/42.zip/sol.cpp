#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int SZ=(int)(1e8)+1;
int np[SZ];
void sieve() {
    np[0]=np[1]=1;
    for (int i=2; i<SZ; i++)
        if(!np[i])
            for (ll j=1LL*i*i; j<SZ; j+=i)
                np[j]=1;
}

string s;
int check(int x) {
    int p=(int)s.length()-1;
    while (x) {
        if (s[p]=='?'||((s[p]-'0')==(x%10))) {
            p--;
            x/=10;
        } else return 0;
    }
    return 1;
}

int main() {
    sieve();
    cin >> s;
    
    int st=1;
    for (int i=1; i<s.length(); i++) st *= 10;

    int ans=0;
    for (int i=st; i<st*10; i++) {
        if (check(i)) {
            ans += !np[i];
        }
    }
    cout << ans;
}
