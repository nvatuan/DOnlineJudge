INPOSTFIX='.in'
OUTPOSTFIX='.out'
CNT=6
START=1

import os
from random import randint, shuffle
cand = [str(i) for i in range(0, 10)]
shuffle(cand)

LEN=7
def gen_input():
    global LEN
    n = ''
    for i in range(LEN-1):
        if randint(0, 100) >= 40:
            n += cand[randint(0, 9)]
        else:
            n += '?'
    n += '?'
    return n

for i in range(START,START+CNT):
    f = open(str(i)+INPOSTFIX, 'w');
    f.write(f"{gen_input()}\n")
    f.close()
    os.system("type " + str(i)+INPOSTFIX + " | sol.exe > " + str(i)+OUTPOSTFIX)
    print('Finish i=', i)
